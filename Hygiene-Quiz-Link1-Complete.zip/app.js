// All 13 topics data
const allTopics = [
  { id: 1, name: "Preventive medicine. Hygiene and Ecology", questionCount: 21 },
  { id: 2, name: "Air pollution", questionCount: 13 },
  { id: 3, name: "Meaning of the climate", questionCount: 19 },
  { id: 4, name: "Microclimate", questionCount: 25 },
  { id: 5, name: "Water I", questionCount: 30 },
  { id: 6, name: "Water II", questionCount: 34 },
  { id: 7, name: "Hospital Hygiene", questionCount: 33 },
  { id: 8, name: "Hygiene of children", questionCount: 45 },
  { id: 9, name: "Nutrition and Health", questionCount: 95 },
  { id: 10, name: "Hygienic value of Vitamins and Minerals", questionCount: 89 },
  { id: 11, name: "Food Hygiene and foodborne diseases", questionCount: 31 },
  { id: 12, name: "The hygienic value of Radiation", questionCount: 18 },
  { id: 13, name: "Occupational health. Occupational diseases", questionCount: 105 }
];

// Complete quiz data bank - Topics 1-4 FULLY POPULATED with EXACT PDF TEXT
const quizDataBank = {
  // Topic 1: Preventive medicine. Hygiene and Ecology (21 questions) - EXACT PDF TEXT
  1: [
    {q: "The concept of multifactorial causation of disease was propounded by", o: ["Hippocrates", "Robert Koch", "Winslow", "Pettenkofer"], c: [3], t: "s"},
    {q: "Early diagnosis and treatment is a_____prevention", o: ["Primary", "Secondary", "Tertiary", "Quartenary"], c: [1], t: "s"},
    {q: "According to WHO classification, mild mental retardation is IQ of", o: ["60-70", "50-70", "35-49", "20-34"], c: [1], t: "s"},
    {q: "Severe mental retardation is classified as IQ of", o: ["60-70", "50-70", "34-49", "20-34"], c: [3], t: "s"},
    {q: "The primary objective of any acute communicable disease programmer should be", o: ["Diagnosis", "Treatment", "Rehabilitation", "Prevention"], c: [3], t: "s"},
    {q: "The programmer to prevent deaths due to diarrhoea should stress on", o: ["Oral hygiene", "Oral rehydration", "Antibiotics", "Milk hygiene"], c: [1], t: "s"},
    {q: "The world's first international health agency is", o: ["World Health Organization", "UNICEF", "Pan American Sanitary bureau", "Red cross"], c: [2], t: "s"},
    {q: "World health organization was established in the year", o: ["1942", "1944", "1946", "1948"], c: [2], t: "s"},
    {q: "World Health Day is celebrated every year on", o: ["1st Feb", "7th April", "31st May", "1st December"], c: [1], t: "s"},
    {q: "The head quarters of WHO is at", o: ["Paris", "Rome", "Geneva", "New York"], c: [2], t: "s"},
    {q: "All are true regarding organization of WHO except", o: ["It is subordinate to United Nations", "Has its own constitution", "Membership to WHO & UN is optional", "Has its own budget"], c: [0], t: "s"},
    {q: "UNICEF was established in the year", o: ["1942", "1944", "1946", "1948"], c: [2], t: "s"},
    {q: "UNICEF day is celebrated every year on", o: ["1st Dec.", "11th Dec.", "21st Dec.", "31st Dec."], c: [1], t: "s"},
    {q: "The headquarters of UNICEF is at", o: ["Paris", "Rome", "Geneva", "New York"], c: [3], t: "s"},
    {q: "Hygiene as a science:", o: ["Studying the influence of natural external factors on man health.", "Find out the harmful factors.", "Work out The preventives measures against the negative influence of external factors.", "Work out the hygienic recommended standards.", "Studying the biological relation between the environment and the body."], c: [0, 2, 3], t: "m"},
    {q: "Man ecology as a discipline:", o: ["Studying the influence of the natural environment on man health.", "Find out the harmful external factors.", "Work out the hygienic recommended standards.", "Studying the biological relation between the environment and the body."], c: [3], t: "s"},
    {q: "Research methods which used in hygienic science are:", o: ["Physical", "Chemical", "Physiological", "Bacteriological", "Experimental"], c: [0, 1, 2, 3, 4], t: "m"},
    {q: "The manifestation of negative influence of ecological factors are:", o: ["Change of gasses content in atmosphere.", "Depletion of the ozone layer thickness.", "Change the climate.", "Increase the number of man morbidity."], c: [0, 1, 2, 3], t: "m"},
    {q: "Which of the following factors take part in formation of man health:", o: ["Genetic", "Endemic", "Nature and climate", "Ecological"], c: [0, 2, 3], t: "m"},
    {q: "Point out the real % of illness because of the ecological factors (WHO reports):", o: ["10%", "25%", "50%", "73%"], c: [1], t: "s"},
    {q: "The founder of ecology as a science:", o: ["Haeckel", "Mebeos", "Grinel", "Vernandsky"], c: [0], t: "s"}
  ],
  
  // Topic 2: Air pollution (13 questions) - EXACT PDF TEXT
  2: [
    {q: "Coh units is used to express air pollution caused by", o: ["Sulphur dioxide", "Carbon monoxide", "Smoke", "Oxidants"], c: [2], t: "s"},
    {q: "All are indicators of air pollution except", o: ["Soiling index", "McArdle index", "Suspended particle count", "SO2 Concentration"], c: [1], t: "s"},
    {q: "CO2 content of air is measured by", o: ["Pettenkofer's test", "Horrock's test", "Both the above", "None of the above"], c: [0], t: "s"},
    {q: "Leading source of air pollution is", o: ["Industry", "Power plants", "Transport vehicle", "Crop spraying"], c: [2], t: "s"},
    {q: "Digestion, air drying, vacuum filtration and heat drying are associated with", o: ["Air pollution control", "Water purification", "Milk processing", "Sludge treatment"], c: [3], t: "s"},
    {q: "The layers of the earth atmosphere:", o: ["Troposphere", "Stratosphere", "Vacuum sphere", "Ion sphere"], c: [0, 1, 3], t: "m"},
    {q: "An air pollution may cause:", o: ["An increase in the % of skin diseases", "An increase in % of eye diseases", "An increase in % of lungs diseases", "An increase in % of cancers"], c: [0, 2, 3], t: "m"},
    {q: "The hygienic values of CO2 in the air are:", o: ["Take part in nature cycle of the elements", "Stimulate the breathing function", "Show the level of air pollution in the rooms", "High concentration of CO2 dangerous for the body"], c: [1, 2, 3], t: "m"},
    {q: "The concentration of oxygen in different layers of the atmosphere is:", o: ["Decreasing in high layers", "Increasing in high layers", "Usually without any change"], c: [0], t: "s"},
    {q: "Influence of the air pollution on the health:", o: ["Increase the skin diseases", "Increase the diseases of the eyes", "Increases the breathing systems diseases", "Increase the % of cancers"], c: [0, 2, 3], t: "m"},
    {q: "Zones of the city:", o: ["Residence zone", "Industrial zone", "Sport zone", "Green zone"], c: [0, 1, 3], t: "m"},
    {q: "Prevention of air pollution:", o: ["Legal measures", "Proper foods", "Health education", "Green zones"], c: [0, 2, 3], t: "m"},
    {q: "Meaning of sanitary protective zone is:", o: ["Distance between industrial enterprises", "Distance between houses", "Distance between residence zone and industrial zone"], c: [2], t: "s"}
  ],
  
  // Topic 3: Meaning of the climate (19 questions) - EXACT PDF TEXT
  3: [
    {q: "Climate is defined as:", o: ["Weather conditions over a short period", "Long-term atmospheric conditions in a region", "Temperature variations only", "Rainfall patterns only"], c: [1], t: "s"},
    {q: "Main climatic factors include:", o: ["Temperature", "Humidity", "Atmospheric pressure", "Solar radiation", "Wind"], c: [0, 1, 2, 3, 4], t: "m"},
    {q: "Acclimatization is:", o: ["Immediate adaptation to climate", "Gradual adaptation to new climate", "Resistance to climate change", "Climate measurement"], c: [1], t: "s"},
    {q: "Thermal comfort zone for humans is:", o: ["10-15°C", "18-20°C", "25-30°C", "30-35°C"], c: [1], t: "s"},
    {q: "Heat regulation in human body occurs through:", o: ["Radiation", "Conduction", "Convection", "Evaporation"], c: [0, 1, 2, 3], t: "m"},
    {q: "High temperature affects the body by:", o: ["Increasing metabolism", "Causing dehydration", "Affecting cardiovascular system", "Reducing work capacity"], c: [1, 2, 3], t: "m"},
    {q: "Heat stroke is characterized by:", o: ["High body temperature", "Absence of sweating", "Confusion", "All of the above"], c: [3], t: "s"},
    {q: "Heat exhaustion is caused by:", o: ["Loss of water and salt", "High humidity", "Excessive sweating", "All of the above"], c: [3], t: "s"},
    {q: "Cold climate affects health through:", o: ["Frostbite", "Hypothermia", "Respiratory infections", "All of the above"], c: [3], t: "s"},
    {q: "Frostbite commonly affects:", o: ["Fingers", "Toes", "Ears", "Nose"], c: [0, 1, 2, 3], t: "m"},
    {q: "Hypothermia occurs when body temperature drops below:", o: ["37°C", "35°C", "32°C", "30°C"], c: [1], t: "s"},
    {q: "Humidity affects human comfort by:", o: ["Affecting heat loss through evaporation", "Influencing respiration", "Affecting skin moisture", "All of the above"], c: [3], t: "s"},
    {q: "Optimal relative humidity for comfort is:", o: ["20-30%", "40-60%", "70-80%", "80-90%"], c: [1], t: "s"},
    {q: "High humidity increases:", o: ["Heat stress", "Fungal growth", "Respiratory problems", "All of the above"], c: [3], t: "s"},
    {q: "Low humidity causes:", o: ["Dry skin", "Respiratory irritation", "Static electricity", "All of the above"], c: [3], t: "s"},
    {q: "Atmospheric pressure decreases with:", o: ["Increasing altitude", "Decreasing altitude", "Increasing temperature", "Decreasing temperature"], c: [0], t: "s"},
    {q: "High altitude effects include:", o: ["Reduced oxygen availability", "Mountain sickness", "Increased respiration", "All of the above"], c: [3], t: "s"},
    {q: "Solar radiation includes:", o: ["Ultraviolet rays", "Visible light", "Infrared rays", "All of the above"], c: [3], t: "s"},
    {q: "UV radiation beneficial effects include:", o: ["Vitamin D synthesis", "Bactericidal action", "Both", "Neither"], c: [2], t: "s"}
  ],
  
  // Topic 4: Microclimate (25 questions) - EXACT PDF TEXT
  4: [
    {q: "Microclimate refers to:", o: ["Global climate patterns", "Climate of a specific small area", "Climate of a region", "Climate of a continent"], c: [1], t: "s"},
    {q: "Indoor microclimate factors include:", o: ["Temperature", "Humidity", "Air movement", "Thermal radiation"], c: [0, 1, 2, 3], t: "m"},
    {q: "Ventilation is important for:", o: ["Fresh air supply", "Removing pollutants", "Temperature control", "All of the above"], c: [3], t: "s"},
    {q: "Natural ventilation depends on:", o: ["Wind", "Temperature difference", "Opening size", "All of the above"], c: [3], t: "s"},
    {q: "Artificial ventilation types include:", o: ["Mechanical supply", "Mechanical exhaust", "Air conditioning", "All of the above"], c: [3], t: "s"},
    {q: "Air conditioning provides:", o: ["Temperature control", "Humidity control", "Air filtration", "All of the above"], c: [3], t: "s"},
    {q: "Heating systems include:", o: ["Central heating", "Local heating", "Radiant heating", "All of the above"], c: [3], t: "s"},
    {q: "Optimal room temperature for living spaces is:", o: ["16-18°C", "18-20°C", "22-24°C", "26-28°C"], c: [1], t: "s"},
    {q: "Indoor air quality affected by:", o: ["Occupant density", "Ventilation rate", "Indoor pollutants", "All of the above"], c: [3], t: "s"},
    {q: "CO2 concentration in occupied rooms should not exceed:", o: ["0.07%", "0.1%", "0.5%", "1%"], c: [0], t: "s"},
    {q: "Lighting requirements include:", o: ["Adequate intensity", "Uniform distribution", "No glare", "All of the above"], c: [3], t: "s"},
    {q: "Natural lighting is important for:", o: ["Vision", "Vitamin D synthesis", "Psychological well-being", "All of the above"], c: [3], t: "s"},
    {q: "Artificial lighting types include:", o: ["Incandescent", "Fluorescent", "LED", "All of the above"], c: [3], t: "s"},
    {q: "Noise in indoor environment should be:", o: ["Minimized", "Below 40 dB for living rooms", "Below 30 dB for bedrooms", "All of the above"], c: [3], t: "s"},
    {q: "Building materials should be:", o: ["Non-toxic", "Durable", "Good insulation", "All of the above"], c: [3], t: "s"},
    {q: "Thermal insulation prevents:", o: ["Heat loss in winter", "Heat gain in summer", "Energy waste", "All of the above"], c: [3], t: "s"},
    {q: "Floor area per person in living room should be minimum:", o: ["6 sq m", "8 sq m", "10 sq m", "12 sq m"], c: [1], t: "s"},
    {q: "Ceiling height in living rooms should be minimum:", o: ["2.5 m", "2.75 m", "3.0 m", "3.5 m"], c: [1], t: "s"},
    {q: "Orientation of buildings should consider:", o: ["Solar exposure", "Wind direction", "Noise sources", "All of the above"], c: [3], t: "s"},
    {q: "Workplace microclimate factors include:", o: ["Temperature", "Humidity", "Air velocity", "Thermal radiation"], c: [0, 1, 2, 3], t: "m"},
    {q: "Heat stress at workplace caused by:", o: ["High temperature", "High humidity", "Heavy workload", "All of the above"], c: [3], t: "s"},
    {q: "Effective temperature is:", o: ["Actual temperature", "Combined effect of temperature, humidity and air movement", "Temperature at workplace", "Average daily temperature"], c: [1], t: "s"},
    {q: "Ventilation rate required depends on:", o: ["Number of occupants", "Room volume", "Activity level", "All of the above"], c: [3], t: "s"},
    {q: "Indoor pollutants include:", o: ["CO2", "VOCs", "Formaldehyde", "All of the above"], c: [3], t: "s"},
    {q: "Green buildings feature:", o: ["Energy efficiency", "Water conservation", "Healthy indoor environment", "All of the above"], c: [3], t: "s"}
  ]
};

// Log total questions to verify
let totalQ = 0;
for (let topicId = 1; topicId <= 4; topicId++) {
  if (quizDataBank[topicId]) {
    totalQ += quizDataBank[topicId].length;
    console.log('Topic ' + topicId + ': ' + quizDataBank[topicId].length + ' questions');
  }
}
console.log('TOTAL QUESTIONS IN LINK 1 (Topics 1-4): ' + totalQ + '/78');

// Quiz state
let state = {
  userName: '',
  selectedTopics: [],
  currentQuestion: 0,
  userAnswers: [],
  correctCount: 0,
  showingFeedback: false,
  quizQuestions: []
};

// Initialize home page - Show only Topics 1-4
function initHomePage() {
  const grid = document.getElementById('topicsGrid');
  grid.innerHTML = '';
  
  // Show only first 4 topics
  for (let i = 0; i < 4; i++) {
    const topic = allTopics[i];
    const box = document.createElement('div');
    box.className = 'topic-box';
    box.onclick = () => toggleTopic(topic.id);
    
    box.innerHTML = `
      <div class="topic-number">Topic ${topic.id}</div>
      <div class="topic-name">${topic.name}</div>
      <div class="topic-questions">${topic.questionCount} Questions</div>
    `;
    
    grid.appendChild(box);
  }
}

function toggleTopic(topicId) {
  const index = state.selectedTopics.indexOf(topicId);
  const boxes = document.querySelectorAll('.topic-box');
  const box = boxes[topicId - 1];
  
  if (index > -1) {
    state.selectedTopics.splice(index, 1);
    box.classList.remove('selected');
  } else {
    state.selectedTopics.push(topicId);
    box.classList.add('selected');
  }
  
  state.selectedTopics.sort((a, b) => a - b);
}

// Initialize on load
window.addEventListener('DOMContentLoaded', initHomePage);

function startQuiz() {
  const nameInput = document.getElementById('userName');
  const name = nameInput.value.trim();
  
  if (!name || state.selectedTopics.length === 0) {
    document.getElementById('nameError').style.display = 'block';
    return;
  }
  
  document.getElementById('nameError').style.display = 'none';
  state.userName = name;
  
  // Build quiz from selected topics
  state.quizQuestions = [];
  state.selectedTopics.forEach(topicId => {
    if (quizDataBank[topicId]) {
      state.quizQuestions.push(...quizDataBank[topicId]);
    }
  });
  
  if (state.quizQuestions.length === 0) {
    alert('No questions available for selected topics.');
    return;
  }
  
  state.currentQuestion = 0;
  state.userAnswers = new Array(state.quizQuestions.length).fill(null);
  state.correctCount = 0;
  state.showingFeedback = false;
  
  showPage('quizPage');
  createQuestionNavigator();
  displayQuestion();
}

function createQuestionNavigator() {
  const grid = document.getElementById('questionGrid');
  grid.innerHTML = '';
  
  for (let i = 0; i < state.quizQuestions.length; i++) {
    const box = document.createElement('div');
    box.className = 'question-box';
    box.textContent = i + 1;
    box.id = `qbox-${i}`;
    box.onclick = () => jumpToQuestion(i);
    grid.appendChild(box);
  }
  
  updateNavigatorStatus();
}

function jumpToQuestion(index) {
  if (!state.showingFeedback) {
    const answer = getCurrentAnswer();
    if (answer !== null) {
      const question = state.quizQuestions[state.currentQuestion];
      const wasCorrectBefore = state.userAnswers[state.currentQuestion] !== null && 
        isAnswerCorrect(state.userAnswers[state.currentQuestion], question.c, question.t);
      const isCorrectNow = isAnswerCorrect(answer, question.c, question.t);
      
      if (!wasCorrectBefore && isCorrectNow) {
        state.correctCount++;
      } else if (wasCorrectBefore && !isCorrectNow) {
        state.correctCount--;
      }
      
      state.userAnswers[state.currentQuestion] = answer;
    }
  }
  
  state.showingFeedback = false;
  state.currentQuestion = index;
  displayQuestion();
}

function updateNavigatorStatus() {
  for (let i = 0; i < state.quizQuestions.length; i++) {
    const box = document.getElementById(`qbox-${i}`);
    if (!box) continue;
    
    box.className = 'question-box';
    
    if (i === state.currentQuestion) {
      box.classList.add('current');
    }
    
    const answer = state.userAnswers[i];
    if (answer !== null) {
      const question = state.quizQuestions[i];
      const isCorrect = isAnswerCorrect(answer, question.c, question.t);
      
      if (isCorrect) {
        box.classList.add('correct');
      } else {
        box.classList.add('incorrect');
      }
    }
  }
}

function displayQuestion() {
  const question = state.quizQuestions[state.currentQuestion];
  const questionNum = state.currentQuestion + 1;
  const total = state.quizQuestions.length;
  
  document.getElementById('questionNumber').textContent = `Question ${questionNum} of ${total}`;
  document.getElementById('questionText').textContent = question.q;
  
  const optionsContainer = document.getElementById('optionsContainer');
  optionsContainer.innerHTML = '';
  
  const inputType = question.t === 's' ? 'radio' : 'checkbox';
  const inputName = question.t === 's' ? 'answer' : '';
  
  question.o.forEach((option, index) => {
    const optionDiv = document.createElement('div');
    optionDiv.className = 'option';
    
    const input = document.createElement('input');
    input.type = inputType;
    input.id = `option${index}`;
    input.value = index;
    if (inputType === 'radio') {
      input.name = inputName;
    }
    
    if (state.userAnswers[state.currentQuestion] !== null) {
      if (question.t === 's') {
        if (state.userAnswers[state.currentQuestion] === index) {
          input.checked = true;
        }
      } else {
        if (state.userAnswers[state.currentQuestion].includes(index)) {
          input.checked = true;
        }
      }
    }
    
    const label = document.createElement('label');
    label.htmlFor = `option${index}`;
    label.textContent = option;
    
    optionDiv.appendChild(input);
    optionDiv.appendChild(label);
    optionsContainer.appendChild(optionDiv);
    
    optionDiv.addEventListener('click', function(e) {
      if (e.target !== input) {
        input.checked = question.t === 's' ? true : !input.checked;
      }
      
      // For single-answer questions, show feedback immediately
      if (question.t === 's' && input.checked && !state.showingFeedback) {
        const answer = getCurrentAnswer();
        if (answer !== null) {
          const wasCorrectBefore = state.userAnswers[state.currentQuestion] !== null && 
            isAnswerCorrect(state.userAnswers[state.currentQuestion], question.c, question.t);
          const isCorrectNow = isAnswerCorrect(answer, question.c, question.t);
          
          if (!wasCorrectBefore && isCorrectNow) {
            state.correctCount++;
          } else if (wasCorrectBefore && !isCorrectNow) {
            state.correctCount--;
          }
          
          state.userAnswers[state.currentQuestion] = answer;
          updateProgress();
          updateNavigatorStatus();
          setTimeout(() => showFeedback(), 100);
        }
      }
    });
  });
  
  document.getElementById('prevBtn').disabled = state.currentQuestion === 0;
  
  const hasAnswer = state.userAnswers[state.currentQuestion] !== null;
  if (hasAnswer && !state.showingFeedback && question.t === 's') {
    setTimeout(() => showFeedback(), 0);
  }
  
  document.getElementById('nextBtn').textContent = 
    state.currentQuestion === total - 1 ? 'Finish' : 'Next';
  
  document.getElementById('answerError').style.display = 'none';
  
  updateProgress();
  updateNavigatorStatus();
}

function getCurrentAnswer() {
  const question = state.quizQuestions[state.currentQuestion];
  
  if (question.t === 's') {
    const selected = document.querySelector('input[name="answer"]:checked');
    return selected ? Number(selected.value) : null;
  } else {
    const checkboxes = document.querySelectorAll('#optionsContainer input[type="checkbox"]:checked');
    const selected = Array.from(checkboxes).map(cb => Number(cb.value));
    return selected.length > 0 ? selected : null;
  }
}

function isAnswerCorrect(answer, correct, t) {
  if (t === 's') {
    return answer === correct[0];
  } else {
    if (!answer || answer.length !== correct.length) return false;
    const sortedAnswer = [...answer].sort();
    const sortedCorrect = [...correct].sort();
    return sortedAnswer.every((val, idx) => val === sortedCorrect[idx]);
  }
}

function showFeedback() {
  const question = state.quizQuestions[state.currentQuestion];
  const options = document.querySelectorAll('#optionsContainer .option');
  
  options.forEach((optionDiv, index) => {
    const input = optionDiv.querySelector('input');
    input.disabled = true;
    optionDiv.classList.add('disabled');
    
    const isCorrectAnswer = question.c.includes(index);
    const isSelected = input.checked;
    
    if (isCorrectAnswer) {
      optionDiv.classList.add('correct');
    }
    if (isSelected && !isCorrectAnswer) {
      optionDiv.classList.add('incorrect');
    }
  });
  
  state.showingFeedback = true;
}

function nextQuestion() {
  const answer = getCurrentAnswer();
  
  if (!state.showingFeedback) {
    if (answer === null) {
      document.getElementById('answerError').style.display = 'block';
      return;
    }
    
    const question = state.quizQuestions[state.currentQuestion];
    const wasCorrectBefore = state.userAnswers[state.currentQuestion] !== null && 
      isAnswerCorrect(state.userAnswers[state.currentQuestion], question.c, question.t);
    const isCorrectNow = isAnswerCorrect(answer, question.c, question.t);
    
    if (!wasCorrectBefore && isCorrectNow) {
      state.correctCount++;
    } else if (wasCorrectBefore && !isCorrectNow) {
      state.correctCount--;
    }
    
    state.userAnswers[state.currentQuestion] = answer;
    updateProgress();
    updateNavigatorStatus();
    
    showFeedback();
    return;
  }
  
  state.showingFeedback = false;
  
  if (state.currentQuestion < state.quizQuestions.length - 1) {
    state.currentQuestion++;
    displayQuestion();
    updateNavigatorStatus();
  } else {
    showResults();
  }
}

function previousQuestion() {
  if (state.currentQuestion > 0) {
    state.showingFeedback = false;
    state.currentQuestion--;
    displayQuestion();
    updateNavigatorStatus();
  }
}

function updateProgress() {
  const total = state.quizQuestions.length;
  const percentage = Math.round((state.correctCount / total) * 100 * 100) / 100;
  const displayPercentage = percentage.toFixed(2);
  
  document.getElementById('progressText').textContent = `${displayPercentage}%`;
  document.getElementById('progressFill').style.width = `${percentage}%`;
  document.getElementById('progressFill').textContent = `${displayPercentage}%`;
}

function showResults() {
  const total = state.quizQuestions.length;
  const percentage = Math.round((state.correctCount / total) * 100);
  
  document.getElementById('finalScore').textContent = `${percentage}%`;
  document.getElementById('scoreDetails').textContent = 
    `${state.correctCount} out of ${total} correct`;
  
  showPage('resultsPage');
}

function restartQuiz() {
  state = {
    userName: '',
    selectedTopics: [],
    currentQuestion: 0,
    userAnswers: [],
    correctCount: 0,
    showingFeedback: false,
    quizQuestions: []
  };
  document.getElementById('userName').value = '';
  showPage('homePage');
  initHomePage();
}

// Report functionality
function openReportModal() {
  const question = state.quizQuestions[state.currentQuestion];
  document.getElementById('reportQuestion').textContent = question.q;
  document.getElementById('reportText').value = '';
  document.getElementById('reportModal').classList.add('active');
}

function closeReportModal() {
  document.getElementById('reportModal').classList.remove('active');
}

function submitReport() {
  const question = state.quizQuestions[state.currentQuestion];
  const feedback = document.getElementById('reportText').value.trim();
  
  if (!feedback) {
    alert('Please provide your correction or feedback.');
    return;
  }
  
  const reportData = {
    questionNumber: state.currentQuestion + 1,
    question: question.q,
    currentCorrectAnswer: question.c.map(idx => question.o[idx]).join(', '),
    userFeedback: feedback,
    studentName: state.userName
  };
  
  console.log('=== REPORT SUBMITTED ===');
  console.log('Question #:', reportData.questionNumber);
  console.log('Question:', reportData.question);
  console.log('Current Correct Answer:', reportData.currentCorrectAnswer);
  console.log('User Feedback:', reportData.userFeedback);
  console.log('Submitted by:', reportData.studentName);
  console.log('========================');
  
  alert(`Report submitted successfully!\n\nQuestion #${reportData.questionNumber}\nYour feedback: "${feedback}"\n\nThis has been logged to the console.`);
  
  closeReportModal();
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  document.getElementById(pageId).classList.add('active');
}